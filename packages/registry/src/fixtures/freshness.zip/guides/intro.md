# Documentation

## Guide

This documentation explains how to configure and run the application with a complete example.
